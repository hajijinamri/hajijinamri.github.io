<template>
  <div class="details">
    <navbar />
    <Nuxt />
  </div>
</template>

<script>
export default {
  layout: "details",
};
</script>

<style scoped>
</style>