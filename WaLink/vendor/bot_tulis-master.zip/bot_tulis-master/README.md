# bot_tulis
<img width=50% src="Screenshot.png">
<b>Module : Pillow, time, os</b>

1. git clone https://github.com/RTechnoS/bot_tulis
2. cd bot_tulis
4. Edit file Tulisan.txt dengan text tugas kalian
3. python3 main.py

--> pilih salah satu kertas</br>
--> pilih salah satu font</br>
--> Masukkan Nama (opsional)</br>
--> Masukkan Kelas (opsional)</br>

* Jika ada error silahkan diulang

5. Proses Berhasil disimpan di folder hasil/

Untuk kertas dan font lebih banyak
bisa menggunakan BOT telegram saya
https://t.me/awakmalas_bot


# Copyright © 2020 Rusman TS
Instagram : @rusman_toby

Email : rusmants.public@pm.me


[![Visits Badge](https://badges.pufler.dev/visits/RTechnoS/bot_tulis?style=for-the-badge&color=blue)](https://github.com/RTechnoS/RTechnoS)
